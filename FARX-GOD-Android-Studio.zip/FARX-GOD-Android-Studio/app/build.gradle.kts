plugins { id("com.android.application") }

android {
    namespace = "com.farx.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.farx.studio"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    testOptions { unitTests { returnDefaultValues = true } }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
