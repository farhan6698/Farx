package org.farx.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Lexer {
    private final String source;
    private final List<Token> tokens = new ArrayList<>();
    private int current, line = 1, column = 1, start, startColumn;

    public Lexer(String source) { this.source = source == null ? "" : source; }

    public List<Token> scan() {
        while (!atEnd()) {
            start = current;
            startColumn = column;
            scanToken();
        }
        tokens.add(new Token(Token.Type.EOF, "", null, line, column));
        return List.copyOf(tokens);
    }

    private boolean atEnd() { return current >= source.length(); }
    private char advance() { char c = source.charAt(current++); column++; return c; }
    private boolean match(char expected) {
        if (atEnd() || source.charAt(current) != expected) return false;
        advance(); return true;
    }
    private char peek() { return atEnd() ? '\0' : source.charAt(current); }
    private void add(Token.Type type) {
        tokens.add(new Token(type, source.substring(start, current), null, line, startColumn));
    }

    private void scanToken() {
        char c = advance();
        switch (c) {
            case ' ', '\t', '\r' -> { }
            case '\n', ';' -> {
                tokens.add(new Token(Token.Type.NEWLINE, "\\n", null, line, startColumn));
                if (c == '\n') { line++; column = 1; }
            }
            case '=' -> add(Token.Type.EQUAL);
            case '+' -> add(Token.Type.PLUS);
            case '-' -> add(Token.Type.MINUS);
            case '*' -> add(Token.Type.STAR);
            case '/' -> {
                if (match('/')) while (peek() != '\n' && !atEnd()) advance();
                else add(Token.Type.SLASH);
            }
            case '(' -> add(Token.Type.LPAREN);
            case ')' -> add(Token.Type.RPAREN);
            case ',' -> add(Token.Type.COMMA);
            case '"', '\'' -> string(c);
            default -> {
                if (Character.isDigit(c)) number();
                else if (Character.isLetter(c) || c == '_') identifier();
                else throw new FarxException("Unexpected character '" + c + "'", line, startColumn);
            }
        }
    }

    private void string(char quote) {
        StringBuilder value = new StringBuilder();
        while (!atEnd() && peek() != quote) {
            char c = advance();
            if (c == '\\' && !atEnd()) {
                char n = advance();
                value.append(switch (n) {
                    case 'n' -> '\n'; case 't' -> '\t'; case 'r' -> '\r'; default -> n;
                });
            } else value.append(c);
        }
        if (atEnd()) throw new FarxException("Unterminated string", line, startColumn);
        advance();
        tokens.add(new Token(Token.Type.STRING, source.substring(start, current),
                value.toString(), line, startColumn));
    }

    private void number() {
        while (Character.isDigit(peek())) advance();
        if (peek() == '.' && current + 1 < source.length()
                && Character.isDigit(source.charAt(current + 1))) {
            advance();
            while (Character.isDigit(peek())) advance();
        }
        String text = source.substring(start, current);
        tokens.add(new Token(Token.Type.NUMBER, text, Double.parseDouble(text), line, startColumn));
    }

    private void identifier() {
        while (Character.isLetterOrDigit(peek()) || peek() == '_') advance();
        String word = source.substring(start, current).toUpperCase(Locale.ROOT);
        Token.Type type = switch (word) {
            case "MODE" -> Token.Type.MODE;
            case "END" -> Token.Type.END;
            case "LINK" -> Token.Type.LINK;
            case "PRINT", "SHOW", "DRUCK" -> Token.Type.PRINT;
            case "LET", "SET", "VAR" -> Token.Type.LET;
            case "TRUE", "WAHR" -> Token.Type.TRUE;
            case "FALSE", "FALSCH" -> Token.Type.FALSE;
            case "NULL", "NIL" -> Token.Type.NULL;
            default -> Token.Type.IDENTIFIER;
        };
        tokens.add(new Token(type, source.substring(start, current), null, line, startColumn));
    }
}
