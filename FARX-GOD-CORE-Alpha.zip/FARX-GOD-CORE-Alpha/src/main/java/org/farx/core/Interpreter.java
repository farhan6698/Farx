package org.farx.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import static org.farx.core.Ast.*;

public final class Interpreter {
    private final Map<String, Object> globals = new LinkedHashMap<>();
    private final Consumer<String> output;
    public Interpreter(Consumer<String> output) {
        this.output = output == null ? System.out::println : output;
    }
    public void execute(List<Stmt> statements) {
        for (Stmt statement : statements) execute(statement);
    }
    private void execute(Stmt s) {
        if (s instanceof Mode m) { execute(m.body()); return; }
        if (s instanceof Print p) { output.accept(stringify(eval(p.value()))); return; }
        if (s instanceof Let l) { globals.put(key(l.name()), eval(l.value())); return; }
        if (s instanceof Link l) {
            throw new FarxException("Module '" + l.module()
                    + "' is not registered yet; LINK loader is not implemented in this alpha",
                    l.line(), 1);
        }
    }
    private Object eval(Expr e) {
        if (e instanceof Literal l) return l.value();
        if (e instanceof Grouping g) return eval(g.expression());
        if (e instanceof Variable v) {
            String k = key(v.name());
            if (!globals.containsKey(k))
                throw new FarxException("Undefined variable '" + v.name() + "'", v.line(), v.column());
            return globals.get(k);
        }
        if (e instanceof Unary u) {
            Object x = eval(u.right());
            if (!(x instanceof Number))
                throw new FarxException("Unary '-' requires a number", u.line(), 1);
            return -((Number) x).doubleValue();
        }
        if (e instanceof Binary b) return binary(eval(b.left()), eval(b.right()), b);
        throw new IllegalStateException("Unknown expression");
    }
    private Object binary(Object a, Object b, Binary node) {
        if (node.operator() == Token.Type.PLUS && (a instanceof String || b instanceof String))
            return stringify(a) + stringify(b);
        if (!(a instanceof Number) || !(b instanceof Number))
            throw new FarxException("Arithmetic operators require numbers", node.line(), 1);
        double x = ((Number) a).doubleValue(), y = ((Number) b).doubleValue();
        return switch (node.operator()) {
            case PLUS -> x + y;
            case MINUS -> x - y;
            case STAR -> x * y;
            case SLASH -> {
                if (y == 0) throw new FarxException("Division by zero", node.line(), 1);
                yield x / y;
            }
            default -> throw new IllegalStateException("Unsupported operator");
        };
    }
    private String key(String s) { return s.toLowerCase(Locale.ROOT); }
    private String stringify(Object o) {
        if (o == null) return "NULL";
        if (o instanceof Double d && d == Math.rint(d)) return Long.toString(d.longValue());
        return String.valueOf(o);
    }
    public Map<String, Object> variables() { return Map.copyOf(globals); }
}
