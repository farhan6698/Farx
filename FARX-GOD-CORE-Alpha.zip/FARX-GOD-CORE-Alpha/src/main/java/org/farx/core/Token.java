package org.farx.core;

public record Token(Type type, String lexeme, Object literal, int line, int column) {
    public enum Type {
        MODE, END, LINK, PRINT, LET, TRUE, FALSE, NULL,
        IDENTIFIER, NUMBER, STRING,
        EQUAL, PLUS, MINUS, STAR, SLASH, LPAREN, RPAREN, COMMA, NEWLINE, EOF
    }
}
