package org.farx.core;

public class FarxException extends RuntimeException {
    private final int line;
    private final int column;

    public FarxException(String message, int line, int column) {
        super(message + " (line " + line + ", column " + column + ")");
        this.line = line;
        this.column = column;
    }
    public int line() { return line; }
    public int column() { return column; }
}
