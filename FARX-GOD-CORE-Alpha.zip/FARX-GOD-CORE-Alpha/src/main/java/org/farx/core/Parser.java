package org.farx.core;

import java.util.ArrayList;
import java.util.List;
import static org.farx.core.Ast.*;

public final class Parser {
    private final List<Token> tokens;
    private int current;
    public Parser(List<Token> tokens) { this.tokens = tokens; }

    public List<Stmt> parse() {
        List<Stmt> out = new ArrayList<>();
        skipLines();
        while (!check(Token.Type.EOF)) { out.add(statement()); skipLines(); }
        return List.copyOf(out);
    }

    private Stmt statement() {
        if (match(Token.Type.MODE)) return mode(previous());
        if (match(Token.Type.PRINT)) {
            Token t = previous(); Expr e = expression(); endLine();
            return new Print(e, t.line());
        }
        if (match(Token.Type.LET)) {
            Token t = previous();
            Token name = consume(Token.Type.IDENTIFIER, "Expected variable name after LET");
            consume(Token.Type.EQUAL, "Expected '=' after variable name");
            Expr e = expression(); endLine();
            return new Let(name.lexeme(), e, t.line());
        }
        if (match(Token.Type.LINK)) {
            Token t = previous();
            Token name = consume(Token.Type.IDENTIFIER, "Expected module name after LINK");
            endLine();
            return new Link(name.lexeme(), t.line());
        }
        throw error(peek(), "Expected MODE, LET, PRINT, or LINK");
    }

    private Stmt mode(Token start) {
        Token name = consume(Token.Type.IDENTIFIER, "Expected CODE after MODE");
        if (!name.lexeme().equalsIgnoreCase("CODE"))
            throw error(name, "This alpha release supports MODE CODE only");
        endLine();
        skipLines();
        List<Stmt> body = new ArrayList<>();
        while (!check(Token.Type.EOF)
                && !(check(Token.Type.END) && checkNext(Token.Type.MODE))) {
            body.add(statement());
            skipLines();
        }
        consume(Token.Type.END, "Expected END MODE");
        Token end = consume(Token.Type.MODE, "Expected MODE after END");
        if (!end.lexeme().equalsIgnoreCase("MODE")) throw error(end, "Expected END MODE");
        endLine();
        return new Mode(name.lexeme(), List.copyOf(body), start.line());
    }

    private Expr expression() { return addition(); }
    private Expr addition() {
        Expr e = multiplication();
        while (match(Token.Type.PLUS, Token.Type.MINUS)) {
            Token op = previous(); e = new Binary(e, op.type(), multiplication(), op.line());
        }
        return e;
    }
    private Expr multiplication() {
        Expr e = unary();
        while (match(Token.Type.STAR, Token.Type.SLASH)) {
            Token op = previous(); e = new Binary(e, op.type(), unary(), op.line());
        }
        return e;
    }
    private Expr unary() {
        if (match(Token.Type.MINUS)) {
            Token op = previous(); return new Unary(op.type(), unary(), op.line());
        }
        return primary();
    }
    private Expr primary() {
        if (match(Token.Type.NUMBER, Token.Type.STRING)) return new Literal(previous().literal());
        if (match(Token.Type.TRUE)) return new Literal(true);
        if (match(Token.Type.FALSE)) return new Literal(false);
        if (match(Token.Type.NULL)) return new Literal(null);
        if (match(Token.Type.IDENTIFIER)) {
            Token t = previous(); return new Variable(t.lexeme(), t.line(), t.column());
        }
        if (match(Token.Type.LPAREN)) {
            Expr e = expression(); consume(Token.Type.RPAREN, "Expected ')'"); return new Grouping(e);
        }
        throw error(peek(), "Expected an expression");
    }

    private void endLine() {
        if (match(Token.Type.NEWLINE)) return;
        if (!check(Token.Type.EOF) && !check(Token.Type.END))
            throw error(peek(), "Expected end of line");
    }
    private void skipLines() { while (match(Token.Type.NEWLINE)) {} }
    private boolean match(Token.Type... types) {
        for (Token.Type t : types) if (check(t)) { advance(); return true; }
        return false;
    }
    private Token consume(Token.Type t, String message) {
        if (check(t)) return advance();
        throw error(peek(), message);
    }
    private boolean check(Token.Type t) { return peek().type() == t; }
    private boolean checkNext(Token.Type t) {
        return current + 1 < tokens.size() && tokens.get(current + 1).type() == t;
    }
    private Token advance() { if (!check(Token.Type.EOF)) current++; return previous(); }
    private Token peek() { return tokens.get(current); }
    private Token previous() { return tokens.get(current - 1); }
    private FarxException error(Token t, String m) {
        return new FarxException(m, t.line(), t.column());
    }
}
