package org.farx.core;

import java.util.List;

public final class Ast {
    private Ast() {}
    public sealed interface Stmt permits Mode, Print, Let, Link {}
    public record Mode(String name, List<Stmt> body, int line) implements Stmt {}
    public record Print(Expr value, int line) implements Stmt {}
    public record Let(String name, Expr value, int line) implements Stmt {}
    public record Link(String module, int line) implements Stmt {}
    public sealed interface Expr permits Literal, Variable, Binary, Unary, Grouping {}
    public record Literal(Object value) implements Expr {}
    public record Variable(String name, int line, int column) implements Expr {}
    public record Binary(Expr left, Token.Type operator, Expr right, int line) implements Expr {}
    public record Unary(Token.Type operator, Expr right, int line) implements Expr {}
    public record Grouping(Expr expression) implements Expr {}
}
