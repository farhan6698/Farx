package org.farx.cli;

import java.nio.file.Files;
import java.nio.file.Path;
import org.farx.core.*;

public final class Farx {
    private Farx() {}
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("FARX GOD CORE 1.0.0-alpha.1\nUsage: farx <file.farx>");
            return;
        }
        try {
            String source = Files.readString(Path.of(args[0]));
            var tokens = new Lexer(source).scan();
            var program = new Parser(tokens).parse();
            new Interpreter(System.out::println).execute(program);
        } catch (FarxException e) {
            System.err.println("FARX ERROR: " + e.getMessage());
            System.exit(1);
        }
    }
}
