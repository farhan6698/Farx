package org.farx.core;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class FarxCoreTest {
    @Test void executesModeVariablesAndArithmetic() {
        String src = "MODE CODE\nLET x = 6 * 7\nPRINT x\nEND MODE\n";
        var out = new ArrayList<String>();
        new Interpreter(out::add).execute(new Parser(new Lexer(src).scan()).parse());
        assertEquals(java.util.List.of("42"), out);
    }
    @Test void keywordsAndNamesAreCaseInsensitive() {
        String src = "mode code\nlet Value = 2 + 3\nprint VALUE\nend mode\n";
        var out = new ArrayList<String>();
        new Interpreter(out::add).execute(new Parser(new Lexer(src).scan()).parse());
        assertEquals(java.util.List.of("5"), out);
    }
    @Test void undefinedVariableProducesLanguageError() {
        String src = "MODE CODE\nPRINT missing\nEND MODE\n";
        assertThrows(FarxException.class,
            () -> new Interpreter(s -> {}).execute(new Parser(new Lexer(src).scan()).parse()));
    }
    @Test void divisionByZeroProducesLanguageError() {
        String src = "MODE CODE\nPRINT 10 / 0\nEND MODE\n";
        assertThrows(FarxException.class,
            () -> new Interpreter(s -> {}).execute(new Parser(new Lexer(src).scan()).parse()));
    }
}
