# FARX GOD CORE — Alpha 1

This is the first executable foundation of FARX as an independent language. It is not the finished FARX 1.0 ecosystem.

## Example

```farx
MODE CODE
LET greeting = "Hello FARX"
LET answer = 6 * 7
PRINT greeting
PRINT answer
END MODE
```

## Run

Requires JDK 17 and Gradle 8+:

```bash
gradle test
gradle run --args="examples/hello.farx"
```

## Implemented now

- Case-insensitive keywords and variable names.
- Lexer, source-positioned tokens, parser and AST.
- `MODE CODE` / `END MODE`.
- `LET` variables and `PRINT`.
- Numbers, strings, booleans and `NULL`.
- Arithmetic precedence, unary minus, parentheses and string concatenation.
- Runtime execution and line/column diagnostics.
- CLI runner and automated tests.

## Not implemented yet

The full IR compiler, optimizer, native code generators, package manager, real `LINK` module loader, debugger, all 150+ executable modes, and desktop/mobile Studio clients are not included in this alpha. `LINK` is recognized by the parser but intentionally reports that its loader is not implemented.

## Roadmap

1. Semantic analysis, symbol tables and static type system.
2. Typed IR, verifier and optimizer.
3. Package manifest, module loader, linker and access checks.
4. Debugger, breakpoints, stack traces and source maps.
5. Mode SDK: DATA, UI, SYSTEM, AUDIO, 2D, 3D and BRAIN.
6. Backend interfaces and FARX Studio clients for desktop/mobile.

FARX remains its own language; foreign-language interoperability will be implemented through explicit bridge/backend interfaces, not by disguising another language as FARX.
