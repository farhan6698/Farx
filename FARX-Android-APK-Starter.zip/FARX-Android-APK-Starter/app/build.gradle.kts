plugins {
    id("com.android.application")
}

android {
    namespace = "com.farx.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.farx.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
